const products = [
    // Smartphones
    { id: 1, name: 'iPhone 16 Pro Max', brand: 'Apple', category: 'smartphone', price: 35590000, originalPrice: 39990000, discount: 11, promo: 'S-Student additional discount up to 300,000đ', rating: 4.8, likes: 200, images: ['images/iphone16_1.jpg', 'images/iphone16_2.jpg', 'images/iphone16_3.jpg'], description: ['6.9-inch Super Retina XDR touch display', 'Advanced camera system with 4K video recording', 'Powerful A18 Pro chip with superior AI support', 'Large battery capacity, 50% charge in 30 minutes'] },
    { id: 2, name: 'Samsung Galaxy S25 Ultra', brand: 'Samsung', category: 'smartphone', price: 30330000, originalPrice: 36990000, discount: 18, promo: 'S-Student additional discount up to 600,000đ', rating: 4.7, likes: 180, images: ['images/samsung_s25_1.jpg', 'images/samsung_s25_2.jpg', 'images/samsung_s25_3.jpg'], description: ['6.8-inch Dynamic AMOLED 2X display', '200MP camera, 8K video recording', 'Snapdragon 8 Gen 4 chip', '5000mAh battery, 45W fast charging'] },
    { id: 3, name: 'Xiaomi Redmi Note 14', brand: 'Xiaomi', category: 'smartphone', price: 5630000, originalPrice: 5990000, discount: 6, promo: 'S-Student additional discount up to 250,000đ', rating: 4.3, likes: 90, images: ['images/xiaomi_note14_1.jpg', 'images/xiaomi_note14_2.jpg', 'images/xiaomi_note14_3.jpg'], description: ['6.67-inch AMOLED display', '50MP camera', 'MediaTek Dimensity 6020 chip', '5000mAh battery, 33W fast charging'] },
    { id: 4, name: 'Xiaomi 15 5G', brand: 'Xiaomi', category: 'smartphone', price: 23750000, originalPrice: 26990000, discount: 12, promo: 'S-Student additional discount up to 300,000đ', rating: 4.6, likes: 110, images: ['images/xiaomi15_1.jpg', 'images/xiaomi15_2.jpg', 'images/xiaomi15_3.jpg'], description: ['6.73-inch AMOLED display', '50MP Leica camera', 'Snapdragon 8 Gen 3 chip', '4800mAh battery, 120W fast charging'] },
    { id: 5, name: 'Samsung Galaxy S25', brand: 'Samsung', category: 'smartphone', price: 21240000, originalPrice: 24990000, discount: 15, promo: 'S-Student additional discount up to 600,000đ', rating: 4.5, likes: 150, images: ['images/samsung_s25b_1.jpg', 'images/samsung_s25b_2.jpg', 'images/samsung_s25b_3.jpg'], description: ['6.2-inch AMOLED display', '50MP camera', 'Snapdragon 8 Gen 4 chip', '4000mAh battery, 25W fast charging'] },
    { id: 6, name: 'Samsung Galaxy S24 Ultra', brand: 'Samsung', category: 'smartphone', price: 30250000, originalPrice: 33990000, discount: 11, promo: 'S-Student additional discount up to 300,000đ', rating: 4.8, likes: 200, images: ['images/samsung_s24_1.jpg', 'images/samsung_s24_2.jpg', 'images/samsung_s24_3.jpg'], description: ['6.8-inch AMOLED display', '200MP camera', 'Snapdragon 8 Gen 3 chip', '5000mAh battery, 45W fast charging'] },
    { id: 7, name: 'iPhone 14', brand: 'Apple', category: 'smartphone', price: 16390000, originalPrice: 19990000, discount: 18, promo: 'S-Student additional discount up to 300,000đ', rating: 4.5, likes: 130, images: ['images/iphone14_1.webp', 'images/iphone14_2.webp', 'images/iphone14_3.webp'], description: ['6.1-inch Super Retina XDR display', '12MP camera', 'A15 Bionic chip', '3279mAh battery, 20W fast charging'] },
    { id: 8, name: 'Samsung Galaxy M55 5G', brand: 'Samsung', category: 'smartphone', price: 9650000, originalPrice: 10490000, discount: 8, promo: 'S-Student additional discount up to 200,000đ', rating: 4.3, likes: 95, images: ['images/samsung_m55_1.webp', 'images/samsung_m55_2.webp', 'images/samsung_m55_3.webp'], description: ['6.7-inch AMOLED display', '50MP camera', 'Snapdragon 7 Gen 1 chip', '5000mAh battery, 45W fast charging'] },
    { id: 9, name: 'iPhone 14 Pro Max', brand: 'Apple', category: 'smartphone', price: 24630000, originalPrice: 27990000, discount: 12, promo: 'S-Student additional discount up to 200,000đ', rating: 4.4, likes: 110, images: ['images/iphone14t_1.webp', 'images/iphone14t_2.webp', 'images/iphone14t_3.webp'], description: ['6.1-inch Super Retina XDR display', '12MP camera', 'A15 Bionic chip', '3279mAh battery, 20W fast charging'] },
    { id: 10, name: 'Samsung Galaxy S24', brand: 'Samsung', category: 'smartphone', price: 21310000, originalPrice: 25990000, discount: 18, promo: 'S-Student additional discount up to 600,000đ', rating: 4.7, likes: 180, images: ['images/samsung_s24b_1.webp', 'images/samsung_s24b_2.webp', 'images/samsung_s24b_3.webp'], description: ['6.2-inch AMOLED display', '50MP camera', 'Snapdragon 8 Gen 3 chip', '4000mAh battery, 25W fast charging'] },
    { id: 11, name: 'OPPO Reno 10', brand: 'OPPO', category: 'smartphone', price: 11890000, originalPrice: 13990000, discount: 15, promo: 'S-Student additional discount up to 200,000đ', rating: 4.4, likes: 120, images: ['images/oppo_reno10_1.webp', 'images/oppo_reno10_2.webp', 'images/oppo_reno10_3.webp'], description: ['6.7-inch AMOLED display', '64MP camera', 'Snapdragon 778G chip', '4600mAh battery, 80W fast charging'] },
    { id: 12, name: 'vivo V29', brand: 'vivo', category: 'smartphone', price: 12890000, originalPrice: 14990000, discount: 14, promo: 'S-Student additional discount up to 200,000đ', rating: 4.5, likes: 130, images: ['images/vivo_v29_1.webp', 'images/vivo_v29_2.webp'], description: ['6.78-inch AMOLED display', '50MP camera', 'Snapdragon 7 Gen 3 chip', '4600mAh battery, 44W fast charging'] },
    { id: 13, name: 'realme 11 Pro', brand: 'realme', category: 'smartphone', price: 9890000, originalPrice: 10990000, discount: 10, promo: 'S-Student additional discount up to 150,000đ', rating: 4.2, likes: 100, images: ['images/realme11_1.webp', 'images/realme11_2.webp', 'images/realme11_3.webp'], description: ['6.7-inch AMOLED display', '100MP camera', 'Dimensity 7050 chip', '5000mAh battery, 67W fast charging'] },
    { id: 14, name: 'ASUS ROG Phone 8', brand: 'ASUS', category: 'smartphone', price: 26690000, originalPrice: 29990000, discount: 11, promo: 'S-Student additional discount up to 400,000đ', rating: 4.7, likes: 150, images: ['images/asus_rog8_1.webp', 'images/asus_rog8_2.webp'], description: ['6.78-inch AMOLED display', '50MP camera', 'Snapdragon 8 Gen 3 chip', '5500mAh battery, 65W fast charging'] },
    { id: 15, name: 'TECNO Spark 20', brand: 'TECNO', category: 'smartphone', price: 3900000, originalPrice: 4490000, discount: 13, promo: 'S-Student additional discount up to 100,000đ', rating: 4.1, likes: 80, images: ['images/tecno_spark20_1.webp', 'images/tecno_spark20_2.webp', 'images/tecno_spark20_3.webp'], description: ['6.6-inch IPS display', '50MP camera', 'Helio G85 chip', '5000mAh battery, 18W fast charging'] },
    { id: 16, name: 'Nokia G22', brand: 'Nokia', category: 'smartphone', price: 4440000, originalPrice: 4990000, discount: 11, promo: 'S-Student additional discount up to 100,000đ', rating: 4.0, likes: 70, images: ['images/nokia_g22_1.webp', 'images/nokia_g22_2.webp', 'images/nokia_g22_3.webp'], description: ['6.5-inch IPS display', '50MP camera', 'Unisoc T606 chip', '5050mAh battery, 20W fast charging'] },
    { id: 17, name: 'Infinix Note 30', brand: 'Infinix', category: 'smartphone', price: 5450000, originalPrice: 5990000, discount: 9, promo: 'S-Student additional discount up to 150,000đ', rating: 4.2, likes: 90, images: ['images/infinix_note30_1.webp', 'images/infinix_note30_2.webp', 'images/infinix_note30_3.webp'], description: ['6.78-inch AMOLED display', '64MP camera', 'Helio G99 chip', '5000mAh battery, 45W fast charging'] },
    { id: 18, name: 'Nothing Phone 2', brand: 'Nothing', category: 'smartphone', price: 15830000, originalPrice: 17990000, discount: 12, promo: 'S-Student additional discount up to 200,000đ', rating: 4.5, likes: 110, images: ['images/nothing_phone2_1.webp', 'images/nothing_phone2_2.webp', 'images/nothing_phone2_3.webp'], description: ['6.7-inch AMOLED display', '50MP camera', 'Snapdragon 8+ Gen 1 chip', '4700mAh battery, 45W fast charging'] },
    // Laptops
    { id: 19, name: 'MacBook Air M2', brand: 'Apple', category: 'laptop', price: 26990000, originalPrice: 29990000, discount: 10, promo: 'S-Student additional discount up to 500,000đ', rating: 4.8, likes: 200, images: ['images/macbook_air_m2_1.webp', 'images/macbook_air_m2_2.webp', 'images/macbook_air_m2_3.webp'], description: ['13.6-inch Retina display', 'M2 chip', '8GB RAM, 256GB SSD', '18-hour battery life'] },
    { id: 20, name: 'ASUS ROG Strix G16', brand: 'ASUS', category: 'laptop', price: 35990000, originalPrice: 38990000, discount: 8, promo: 'S-Student additional discount up to 600,000đ', rating: 4.7, likes: 180, images: ['images/asus_rog_strix_1.webp', 'images/asus_rog_strix_2.webp', 'images/asus_rog_strix_3.webp'], description: ['16-inch 165Hz display', 'Intel Core i9 CPU', 'RTX 4070 GPU', '16GB RAM, 1TB SSD'] },
    { id: 21, name: 'Dell XPS 13', brand: 'Dell', category: 'laptop', price: 31490000, originalPrice: 34990000, discount: 10, promo: 'S-Student additional discount up to 500,000đ', rating: 4.6, likes: 150, images: ['images/dell_xps13_1.webp', 'images/dell_xps13_2.webp', 'images/dell_xps13_3.webp'], description: ['13.4-inch OLED display', 'Intel Core i7 CPU', '16GB RAM, 512GB SSD', '12-hour battery life'] },
    { id: 22, name: 'HP Pavilion 15', brand: 'HP', category: 'laptop', price: 16190000, originalPrice: 17990000, discount: 10, promo: 'S-Student additional discount up to 300,000đ', rating: 4.4, likes: 120, images: ['images/hp_pavilion_1.webp', 'images/hp_pavilion_2.webp', 'images/hp_pavilion_3.webp'], description: ['15.6-inch FHD display', 'Intel Core i5 CPU', '8GB RAM, 512GB SSD', '8-hour battery life'] },
    { id: 23, name: 'Lenovo ThinkPad X1', brand: 'Lenovo', category: 'laptop', price: 34190000, originalPrice: 36990000, discount: 8, promo: 'S-Student additional discount up to 600,000đ', rating: 4.7, likes: 170, images: ['images/lenovo_thinkpad_1.webp', 'images/lenovo_thinkpad_2.webp', 'images/lenovo_thinkpad_3.webp'], description: ['14-inch 2.8K display', 'Intel Core i7 CPU', '16GB RAM, 1TB SSD', '16-hour battery life'] },
    { id: 24, name: 'Acer Nitro 5', brand: 'Acer', category: 'laptop', price: 20990000, originalPrice: 23990000, discount: 13, promo: 'S-Student additional discount up to 400,000đ', rating: 4.5, likes: 140, images: ['images/acer_nitro5_1.webp', 'images/acer_nitro5_2.webp', 'images/acer_nitro5_3.webp'], description: ['15.6-inch 144Hz display', 'Intel Core i5 CPU', 'RTX 3050 GPU', '16GB RAM, 512GB SSD'] },
    { id: 25, name: 'MSI Prestige 14', brand: 'MSI', category: 'laptop', price: 26990000, originalPrice: 29990000, discount: 10, promo: 'S-Student additional discount up to 500,000đ', rating: 4.6, likes: 160, images: ['images/msi_prestige_1.webp', 'images/msi_prestige_2.webp', 'images/msi_prestige_3.webp'], description: ['14-inch 4K display', 'Intel Core i7 CPU', '16GB RAM, 512GB SSD', '10-hour battery life'] },
    { id: 26, name: 'LG Gram 16', brand: 'LG', category: 'laptop', price: 29690000, originalPrice: 32990000, discount: 10, promo: 'S-Student additional discount up to 500,000đ', rating: 4.7, likes: 170, images: ['images/lg_gram_1.webp', 'images/lg_gram_2.webp', 'images/lg_gram_3.webp'], description: ['16-inch WQXGA display', 'Intel Core i7 CPU', '16GB RAM, 512GB SSD', '20-hour battery life'] },
    { id: 27, name: 'Razer Blade 15', brand: 'Razer', category: 'laptop', price: 40990000, originalPrice: 43990000, discount: 7, promo: 'S-Student additional discount up to 700,000đ', rating: 4.8, likes: 190, images: ['images/razer_blade_1.jpg', 'images/razer_blade_2.jpg', 'images/razer_blade_3.jpg'], description: ['15.6-inch 240Hz display', 'Intel Core i9 CPU', 'RTX 4080 GPU', '16GB RAM, 1TB SSD'] },
    { id: 28, name: 'Microsoft Surface Laptop 5', brand: 'Microsoft', category: 'laptop', price: 25190000, originalPrice: 27990000, discount: 10, promo: 'S-Student additional discount up to 400,000đ', rating: 4.5, likes: 130, images: ['images/surface_laptop_1.jpg', 'images/surface_laptop_2.jpg', 'images/surface_laptop_3.jpg'], description: ['13.5-inch PixelSense display', 'Intel Core i5 CPU', '8GB RAM, 256GB SSD', '18-hour battery life'] },
    // Tablets
    { id: 29, name: 'Samsung Galaxy Tab S9 FE Plus WiFi', brand: 'Samsung', category: 'tablet', price: 13520000, originalPrice: 16990000, discount: 20, promo: 'S-Student additional discount up to 300,000đ', rating: 4.6, likes: 120, images: ['images/tab_s9fe_1.webp', 'images/tab_s9fe_2.webp', 'images/tab_s9fe_3.webp'], description: ['12.4-inch display', 'Exynos 1380 chip', '12GB RAM, 256GB storage', '10090mAh battery, 45W fast charging'] },
    { id: 30, name: 'Xiaomi Redmi Pad SE WiFi', brand: 'Xiaomi', category: 'tablet', price: 4790000, originalPrice: 5990000, discount: 20, promo: 'S-Student additional discount up to 200,000đ', rating: 4.2, likes: 85, images: ['images/redmi_pad_1.webp', 'images/redmi_pad_2.webp', 'images/redmi_pad_3.webp'], description: ['11-inch display', 'Snapdragon 680 chip', '6GB RAM, 128GB storage', '8000mAh battery, 18W fast charging'] },
    { id: 31, name: 'iPad Air 5 10.9 inch', brand: 'Apple', category: 'tablet', price: 16190000, originalPrice: 17990000, discount: 10, promo: 'S-Student additional discount up to 300,000đ', rating: 4.7, likes: 150, images: ['images/ipad_air5_1.webp', 'images/ipad_air5_2.webp', 'images/ipad_air5_3.webp'], description: ['10.9-inch Liquid Retina display', 'M1 chip', '8GB RAM, 256GB storage', '10-hour battery life'] },
    { id: 32, name: 'Samsung Galaxy Tab A9', brand: 'Samsung', category: 'tablet', price: 4040000, originalPrice: 4490000, discount: 10, promo: 'S-Student additional discount up to 100,000đ', rating: 4.3, likes: 90, images: ['images/tab_a9_1.webp', 'images/tab_a9_2.webp', 'images/tab_a9_3.webp'], description: ['8.7-inch display', 'Helio G99 chip', '4GB RAM, 64GB storage', '5100mAh battery, 15W fast charging'] },
    { id: 33, name: 'Lenovo Tab M10', brand: 'Lenovo', category: 'tablet', price: 4940000, originalPrice: 5490000, discount: 10, promo: 'S-Student additional discount up to 150,000đ', rating: 4.2, likes: 80, images: ['images/lenovo_tab_m10_1.webp', 'images/lenovo_tab_m10_2.webp', 'images/lenovo_tab_m10_3.webp'], description: ['10.1-inch display', 'Unisoc T610 chip', '4GB RAM, 64GB storage', '5100mAh battery, 10W fast charging'] },
    // Accessories
    { id: 34, name: 'AirPods Pro 2', brand: 'Apple', category: 'accessory', price: 5840000, originalPrice: 6490000, discount: 10, promo: 'S-Student additional discount up to 100,000đ', rating: 4.8, likes: 200, images: ['images/airpods_pro2_1.webp', 'images/airpods_pro2_2.webp', 'images/airpods_pro2_3.webp'], description: ['Active noise cancellation', 'H2 chip', '6-hour listening time', 'Wireless charging support'] },
    { id: 35, name: 'Samsung Galaxy Buds 2 Pro', brand: 'Samsung', category: 'accessory', price: 4040000, originalPrice: 4490000, discount: 10, promo: 'S-Student additional discount up to 100,000đ', rating: 4.6, likes: 150, images: ['images/galaxy_buds2_1.webp', 'images/galaxy_buds2_2.webp', 'images/galaxy_buds2_3.webp'], description: ['Active noise cancellation', '360 audio', '5-hour listening time', 'Wireless charging support'] },
    { id: 36, name: 'Xiaomi Smart Band 8', brand: 'Xiaomi', category: 'accessory', price: 1035000, originalPrice: 1290000, discount: 20, promo: 'S-Student additional discount up to 50,000đ', rating: 4.4, likes: 120, images: ['images/xiaomi_band8_1.webp', 'images/xiaomi_band8_2.webp', 'images/xiaomi_band8_3.webp'], description: ['1.62-inch AMOLED display', 'Health tracking', '16-day battery life', '5ATM water resistance'] },
    { id: 37, name: 'Anker Power Bank 20000mAh', brand: 'Anker', category: 'accessory', price: 1260000, originalPrice: 1490000, discount: 15, promo: 'S-Student additional discount up to 50,000đ', rating: 4.5, likes: 130, images: ['images/anker_powerbank_1.jpg'], description: ['20000mAh capacity', '20W fast charging', '2 USB-C ports', '18-month warranty'] },
    { id: 38, name: 'Logitech MX Master 3 Mouse', brand: 'Logitech', category: 'accessory', price: 2510000, originalPrice: 2790000, discount: 10, promo: 'S-Student additional discount up to 100,000đ', rating: 4.7, likes: 160, images: ['images/logitech_mx_1.jpg', 'images/logitech_mx_2.jpg', 'images/logitech_mx_3.jpg'], description: ['4000 DPI sensor', 'USB/Bluetooth connectivity', '70-day battery life', 'Ergonomic design'] },
    { id: 39, name: 'Apple Watch Series 9 41mm', brand: 'Apple', category: 'accessory', price: 10790000, originalPrice: 11990000, discount: 10, promo: 'S-Student additional discount up to 200,000đ', rating: 4.8, likes: 180, images: ['images/apple_watch9_1.webp', 'images/apple_watch9_2.webp', 'images/apple_watch9_3.webp'], description: ['41mm Retina display', 'S9 chip', 'Health tracking', '18-hour battery life'] },
    { id: 40, name: 'Samsung Galaxy Watch 6 40mm', brand: 'Samsung', category: 'accessory', price: 7190000, originalPrice: 7990000, discount: 10, promo: 'S-Student additional discount up to 150,000đ', rating: 4.6, likes: 140, images: ['images/galaxy_watch6_1.webp', 'images/galaxy_watch6_2.webp', 'images/galaxy_watch6_3.webp'], description: ['1.3-inch AMOLED display', 'Health tracking', '40-hour battery life', '5ATM water resistance'] }
];


let cart = [];
let currentPage = 1;
const productsPerPage = 12;
let filteredProducts = [...products];
let selectedProduct = null;
let selectedStorage = "256GB";
let selectedPrice = 0;
let isLoggedIn = false;
let currentUser = null;
let userProfile = {
    username: "",
    email: "",
    phone: "",
    address: ""
};

// Banner Slideshow
const bannerImages = ['images/banner1.jpg', 'images/banner2.jpg', 'images/banner3.jpg'];
let currentSlide = 0;

function showSlide(index) {
    const bannerImage = document.getElementById('bannerImage');
    bannerImage.style.opacity = 0;
    setTimeout(() => {
        bannerImage.src = bannerImages[index];
        bannerImage.style.opacity = 1;
    }, 500);
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % bannerImages.length;
    showSlide(currentSlide);
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + bannerImages.length) % bannerImages.length;
    showSlide(currentSlide);
}

setInterval(nextSlide, 5000);

// Hiển thị danh sách sản phẩm
function displayProducts(productsToDisplay) {
    const start = (currentPage - 1) * productsPerPage;
    const end = start + productsPerPage;
    const paginatedProducts = productsToDisplay.slice(start, end);

    document.getElementById("productList").innerHTML = paginatedProducts.map(p => `
        <div class="product" onclick="showProductDetail(${p.id})">
            <span class="discount">Discount ${p.discount}%</span>
            <img src="${p.images[0]}" alt="${p.name}">
            <h3>${p.name}</h3>
            <div class="price">${p.price.toLocaleString()}đ <span class="original-price">${p.originalPrice.toLocaleString()}đ</span></div>
            <div class="promo">${p.promo}</div>
            <div class="rating">
                <span class="stars">★ ${p.rating}</span>
                <span class="likes"><span class="heart">♥</span> Likes ${p.likes}</span>
            </div>
        </div>
    `).join('');

    updatePagination(productsToDisplay.length);
}

function updatePagination(totalProducts) {
    const totalPages = Math.ceil(totalProducts / productsPerPage);
    let paginationHTML = '';

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `<button class="${i === currentPage ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
    }

    document.getElementById("pagination").innerHTML = paginationHTML;
}

function changePage(page) {
    currentPage = page;
    displayProducts(filteredProducts);
}

function loadProducts() {
    filteredProducts = [...products];
    currentPage = 1;
    displayProducts(filteredProducts);
}

function filterCategory(category) {
    filteredProducts = products.filter(p => p.category === category);
    currentPage = 1;
    displayProducts(filteredProducts);
}

function filterBrand(brand) {
    filteredProducts = products.filter(p => p.brand === brand);
    currentPage = 1;
    displayProducts(filteredProducts);
}

function sortProducts(criteria) {
    if (criteria === 'price-asc') {
        filteredProducts.sort((a, b) => a.price - b.price);
    } else if (criteria === 'price-desc') {
        filteredProducts.sort((a, b) => b.price - b.price);
    } else {
        filteredProducts = [...products];
    }
    currentPage = 1;
    displayProducts(filteredProducts);
}

// Hiển thị chi tiết sản phẩm
function showProductDetail(id) {
    selectedProduct = products.find(p => p.id === id);
    if (selectedProduct) {
        selectedStorage = "256GB";
        selectedPrice = selectedProduct.price;
        let selectedColor = "Black";

        document.getElementById("productList").style.display = "none";
        document.getElementById("pagination").style.display = "none";
        document.getElementById("cart").style.display = "none";
        document.getElementById("profile").style.display = "none";
        document.getElementById("contact").style.display = "none";
        document.getElementById("productDetail").style.display = "block";

        document.getElementById("detailImage").src = selectedProduct.images[0];
        document.getElementById("detailName").innerText = selectedProduct.name;
        document.getElementById("detailRating").innerText = selectedProduct.rating;
        document.getElementById("detailLikes").innerText = selectedProduct.likes;
        document.getElementById("detailPrice").innerText = selectedPrice.toLocaleString() + "đ";
        document.getElementById("detailOriginalPrice").innerText = selectedProduct.originalPrice.toLocaleString() + "đ";
        document.getElementById("detailDiscount").innerText = `Discount ${selectedProduct.discount}%`;
        document.getElementById("detailDescription").innerHTML = selectedProduct.description.map(desc => `<li>${desc}</li>`).join('');

        const thumbnailGallery = document.getElementById("thumbnailGallery");
        thumbnailGallery.innerHTML = selectedProduct.images.map((imgSrc, index) => `
            <img src="${imgSrc}" alt="Thumbnail ${index + 1}" onclick="changeDetailImage('${imgSrc}')">
        `).join('');
        thumbnailGallery.querySelector("img").classList.add("active");

        const variantOptions = document.getElementById("variantOptions");
        variantOptions.innerHTML = "";
        if (selectedProduct.category === "smartphone") {
            variantOptions.innerHTML = `
                <h4>Select Storage:</h4>
                <div class="storage-options">
                    <button onclick="selectStorage(256, ${selectedProduct.price}, '256GB')">256GB</button>
                    <button onclick="selectStorage(512, ${selectedProduct.price + 1000000}, '512GB')">512GB</button>
                    <button onclick="selectStorage(1000, ${selectedProduct.price + 12000000}, '1TB')">1TB</button>
                </div>
                <h4>Select Color:</h4>
                <div class="color-options">
                    <button onclick="selectColor('Black')">Black</button>
                    <button onclick="selectColor('White')">White</button>
                    <button onclick="selectColor('Blue')">Blue</button>
                </div>
            `;
        } else if (selectedProduct.category === "laptop") {
            variantOptions.innerHTML = `
                <h4>Select Configuration:</h4>
                <div class="storage-options">
                    <button onclick="selectStorage(256, ${selectedProduct.price}, '8GB RAM, 256GB SSD')">8GB RAM, 256GB SSD</button>
                    <button onclick="selectStorage(512, ${selectedProduct.price + 5000000}, '16GB RAM, 512GB SSD')">16GB RAM, 512GB SSD</button>
                </div>
            `;
        } else if (selectedProduct.category === "tablet") {
            variantOptions.innerHTML = `
                <h4>Select Version:</h4>
                <div class="storage-options">
                    <button onclick="selectStorage(128, ${selectedProduct.price}, 'WiFi 128GB')">WiFi 128GB</button>
                    <button onclick="selectStorage(256, ${selectedProduct.price + 2000000}, '5G 256GB')">5G 256GB</button>
                </div>
            `;
        } else if (selectedProduct.category === "accessory") {
            variantOptions.innerHTML = "<p>This product has no configuration options.</p>";
        }

        const storageButtons = variantOptions.querySelectorAll(".storage-options button");
        storageButtons.forEach(button => {
            button.classList.remove("active");
            if (button.innerText.includes("256") || button.innerText.includes("WiFi")) {
                button.classList.add("active");
            }
        });

        const colorButtons = variantOptions.querySelectorAll(".color-options button");
        colorButtons.forEach(button => {
            button.classList.remove("active");
            if (button.innerText === "Black") {
                button.classList.add("active");
            }
        });
    }
}

function selectStorage(storage, price, label) {
    selectedStorage = label;
    selectedPrice = price;
    document.getElementById("detailPrice").innerText = price.toLocaleString() + "đ";
    
    const storageButtons = document.querySelectorAll(".storage-options button");
    storageButtons.forEach(button => {
        button.classList.remove("active");
        if (button.innerText === label) {
            button.classList.add("active");
        }
    });
}

function selectColor(color) {
    selectedColor = color;
    
    const colorButtons = document.querySelectorAll(".color-options button");
    colorButtons.forEach(button => {
        button.classList.remove("active");
        if (button.innerText === color) {
            button.classList.add("active");
        }
    });
}

function changeDetailImage(src) {
    const detailImage = document.getElementById("detailImage");
    detailImage.style.opacity = 0;
    setTimeout(() => {
        detailImage.src = src;
        detailImage.style.opacity = 1;
    }, 300);

    const thumbnails = document.querySelectorAll(".thumbnail-gallery img");
    thumbnails.forEach(thumb => {
        thumb.classList.remove("active");
        if (thumb.src.includes(src)) {
            thumb.classList.add("active");
        }
    });
}

// Giỏ hàng
function addToCartFromDetail() {
    if (checkLogin() && selectedProduct) {
        const productToAdd = { ...selectedProduct, price: selectedPrice, name: `${selectedProduct.name} (${selectedStorage})`, quantity: 1 };
        const existingItem = cart.find(item => item.name === productToAdd.name);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push(productToAdd);
        }
        updateCartView();
        alert("Added to cart!");
    }
}

function buyNowFromDetail() {
    if (checkLogin() && selectedProduct) {
        const productToAdd = { ...selectedProduct, price: selectedPrice, name: `${selectedProduct.name} (${selectedStorage})`, quantity: 1 };
        const existingItem = cart.find(item => item.name === productToAdd.name);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push(productToAdd);
        }
        updateCartView();
        showCart();
    }
}
// Ẩn floating buttons khi click vào bất kỳ button nào trong đó
document.querySelectorAll('.floating-buttons button, .floating-buttons a button').forEach(button => {
    button.addEventListener('click', function() {
        document.querySelector('.floating-buttons').style.display = 'none';
    });
});

function showCart() {
    document.getElementById("productList").style.display = "none";
    document.getElementById("pagination").style.display = "none";
    document.getElementById("productDetail").style.display = "none";
    document.getElementById("profile").style.display = "none";
    document.getElementById("contact").style.display = "none";
    document.getElementById("cart").style.display = "block";
    updateCartView();
}

function updateCartView() {
    let cartItemsDiv = document.getElementById("cartItems");
    if (cart.length === 0) {
        cartItemsDiv.innerHTML = "<p>Cart is empty</p>";
        document.getElementById("cartTotal").innerText = "0đ";
    } else {
        cartItemsDiv.innerHTML = cart.map((item, index) => `
            <div class="cart-item">
                <img src="${item.images[0]}" alt="${item.name}">
                <h4>${item.name}</h4>
                <p>${item.price.toLocaleString()}đ</p>
                <div class="quantity">
                    <button onclick="decreaseQuantity(${index})">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="increaseQuantity(${index})">+</button>
                </div>
                <button onclick="removeFromCart(${index})">❌ Remove</button>
            </div>
        `).join('');
        const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
        document.getElementById("cartTotal").innerText = total.toLocaleString() + "đ";
    }
    document.getElementById("cartCount").innerText = cart.length;
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartView();
}

function increaseQuantity(index) {
    cart[index].quantity += 1;
    updateCartView();
}

function decreaseQuantity(index) {
    if (cart[index].quantity > 1) {
        cart[index].quantity -= 1;
    } else {
        cart.splice(index, 1);
    }
    updateCartView();
}

function clearCart() {
    if (checkLogin()) {
        cart = [];
        updateCartView();
    }
}

function showProducts() {
    document.getElementById("productList").style.display = "grid";
    document.getElementById("pagination").style.display = "flex";
    document.getElementById("cart").style.display = "none";
    document.getElementById("productDetail").style.display = "none";
    document.getElementById("profile").style.display = "none";
    document.getElementById("contact").style.display = "none";
    displayProducts(filteredProducts);
}

function checkout() {
    if (checkLogin() && cart.length > 0) {
        alert("Thank you for your purchase!");
        cart = [];
        updateCartView();
        showProducts();
    } else if (cart.length === 0) {
        alert("Your cart is empty!");
    }
}

// Tìm kiếm sản phẩm
function searchProduct() {
    let query = document.getElementById("searchBox").value.trim().toLowerCase();
    filteredProducts = products.filter(p => 
        p.name.toLowerCase().includes(query) ||
        p.brand.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query)
    );
    
    if (query === "") {
        filteredProducts = [...products];
    }

    if (filteredProducts.length === 0) {
        document.getElementById("productList").innerHTML = "<p>No products found.</p>";
        document.getElementById("pagination").style.display = "none";
    } else {
        currentPage = 1;
        displayProducts(filteredProducts);
        document.getElementById("pagination").style.display = "flex";
    }
}

document.getElementById("searchBox").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        searchProduct();
    }
});

// Đăng nhập/Đăng ký
function showAuthModal() {
    document.getElementById("authModal").style.display = "flex";
}

function closeAuthModal() {
    document.getElementById("authModal").style.display = "none";
}

function toggleAuthMode() {
    const isLogin = document.getElementById("authTitle").innerText === "Login";
    document.getElementById("authTitle").innerText = isLogin ? "Register" : "Login";
    document.getElementById("submitAuth").innerText = isLogin ? "Register" : "Login";
    document.getElementById("authSwitch").innerText = isLogin ? "Already have an account? Login" : "Don't have an account? Register now";
}

document.getElementById("authForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const isLogin = document.getElementById("authTitle").innerText === "Login";

    if (isLogin) {
        const users = JSON.parse(localStorage.getItem("users") || "[]");
        const user = users.find(u => u.username === username && u.password === password);
        if (user) {
            isLoggedIn = true;
            currentUser = username;
            document.getElementById("authButton").innerText = `Hello, ${username}`;
            document.getElementById("authButton").style.display = "none";
            document.getElementById("profileButton").style.display = "inline-flex";
            
            const storedProfile = JSON.parse(localStorage.getItem(`profile_${username}`));
            if (storedProfile) {
                userProfile = storedProfile;
            } else {
                userProfile.username = username;
            }
            closeAuthModal();
            alert("Login successful!");
        } else {
            alert("Incorrect username or password!");
        }
    } else {
        let users = JSON.parse(localStorage.getItem("users") || "[]");
        if (users.some(u => u.username === username)) {
            alert("Username already exists!");
        } else {
            users.push({ username, password });
            localStorage.setItem("users", JSON.stringify(users));
            userProfile.username = username;
            alert("Registration successful! Please login.");
            toggleAuthMode();
        }
    }
});

function checkLogin() {
    if (!isLoggedIn) {
        alert("Please login to perform this action!");
        showAuthModal();
        return false;
    }
    return true;
}

document.getElementById("authButton").addEventListener("click", function() {
    if (isLoggedIn) {
        isLoggedIn = false;
        currentUser = null;
        document.getElementById("authButton").innerText = "Login";
        document.getElementById("authButton").style.display = "inline-flex";
        document.getElementById("profileButton").style.display = "none";
        cart = [];
        updateCartView();
        showProducts();
        alert("Logged out!");
    } else {
        showAuthModal();
    }
});

// Profile
function showProfile() {
    document.getElementById("productList").style.display = "none";
    document.getElementById("pagination").style.display = "none";
    document.getElementById("cart").style.display = "none";
    document.getElementById("productDetail").style.display = "none";
    document.getElementById("contact").style.display = "none";
    document.getElementById("profile").style.display = "block";

    document.getElementById("profileUsername").innerText = userProfile.username;
    document.getElementById("profileEmail").innerText = userProfile.email || "Not set";
    document.getElementById("profilePhone").innerText = userProfile.phone || "Not set";
    document.getElementById("profileAddress").innerText = userProfile.address || "Not set";
}

function showEditProfile() {
    document.getElementById("editProfileModal").style.display = "flex";
    document.getElementById("editEmail").value = userProfile.email || "";
    document.getElementById("editPhone").value = userProfile.phone || "";
    document.getElementById("editAddress").value = userProfile.address || "";
}

function closeEditProfileModal() {
    document.getElementById("editProfileModal").style.display = "none";
}

document.getElementById("editProfileForm").addEventListener("submit", function(event) {
    event.preventDefault();
    userProfile.email = document.getElementById("editEmail").value;
    userProfile.phone = document.getElementById("editPhone").value;
    userProfile.address = document.getElementById("editAddress").value;
    
    localStorage.setItem(`profile_${currentUser}`, JSON.stringify(userProfile));
    closeEditProfileModal();
    showProfile();
    alert("Profile updated successfully!");
});

function showOrderHistory() {
    alert("Order history feature coming soon!");
}

// Contact
function showContact() {
    document.getElementById("productList").style.display = "none";
    document.getElementById("pagination").style.display = "none";
    document.getElementById("cart").style.display = "none";
    document.getElementById("productDetail").style.display = "none";
    document.getElementById("profile").style.display = "none";
    document.getElementById("contact").style.display = "block";
}

document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const subject = document.getElementById("contactSubject").value;
    const message = document.getElementById("contactMessage").value;
    
    if (isLoggedIn) {
        const contactData = {
            username: currentUser,
            email: userProfile.email,
            subject: subject,
            message: message,
            timestamp: new Date().toISOString()
        };
        
        let messages = JSON.parse(localStorage.getItem("contactMessages") || "[]");
        messages.push(contactData);
        localStorage.setItem("contactMessages", JSON.stringify(messages));
        
        alert("Your message has been sent to the admin!");
        document.getElementById("contactSubject").value = "";
        document.getElementById("contactMessage").value = "";
        showProducts();
    } else {
        alert("Please login to send a message to the admin!");
        showAuthModal();
    }
});

window.onload = loadProducts;